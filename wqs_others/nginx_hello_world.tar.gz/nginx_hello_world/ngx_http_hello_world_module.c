#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>

static char *ngx_http_hello_world(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);

/*命名规则：ngx_http_<模块名称>_commands*/
static ngx_command_t ngx_http_hello_world_commands[] = {

    {
        ngx_string("hello_world"),              /*指定模块在配置文件中的指令名称，不能有空格，大小写敏感，数据类型为ngx_str_t*/
        NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,      /*指令的作用于以及参数的个数，多个设定用'|'连接*/
        ngx_http_hello_world,                   /*回掉函数*/
        0,                                      /*用于告诉nginx是把要保持的值放在全局配置部分，server主机配置部分，还是location配置部分，具体的值有nginx定义的宏*/
        0,                                      /*设置指令的值保存在结构体的哪个位置*/
        NULL
    },

    ngx_null_command
};

/*命名规则：ngx_http_<模块名称>_module_ctx*/
static ngx_http_module_t ngx_http_hello_world_module_ctx = {
    NULL,                                   /*读入配置前调用, 原型：ngx_int_t (*preconfiguration)(ngx_conf_t *cf)*/
    NULL,                                   /*读入配置后调用, 原型：ngx_int_t (*postconfiguration)(ngx_conf_t *cf)*/

    NULL,                                   /*创建全局部分配置时调用, 原型：void *(*create_main_conf)(ngx_conf_t *cf)*/
    NULL,                                   /*初始化全局部分的配置时调用, 原型：char *(*init_main_conf)(ngx_conf_t *cf, void *conf)*/

    NULL,                                   /*创建虚拟主机部分的配置时调用, 原型：void *(*create_srv_conf)(ngx_conf_t *cf)*/
    NULL,                                   /*与全局部分配置合并时调用, 原型：char *(*merge_srv_conf)(ngx_conf_t *cf, void *prev, void *conf)*/

    NULL,                                   /*创建location部分的配置时调用, 原型：void *(*create_loc_conf)(ngx_conf_t *cf)*/
    NULL                                    /*与虚拟主机部分配置合并时调用, 原型：char *(*merge_loc_conf)(ngx_conf_t *cf, void *prev, void *conf)*/
};

/*命名规则：ngx_http_<模块名称>_module*/
ngx_module_t ngx_http_hello_world_module = {
    NGX_MODULE_V1,                          /*模块版本*/
    &ngx_http_hello_world_module_ctx,       /*指向特定类型模块的公共接口*/
    ngx_http_hello_world_commands,          /*用于处理配置文件nginx.conf中的配置项*/
    NGX_HTTP_MODULE,                        /*当前模块类型*/

    NULL,                                   /*init master, 原型：ngx_int_t (*init_master)(ngx_log_t *log);*/
    NULL,                                   /*init module, 原型：ngx_int_t (*init_module)(ngx_cycle_t*cycle);*/
    NULL,                                   /*init process, 原型：ngx_int_t (*init_process)(ngx_cycle_t *cycle);*/
    NULL,                                   /*init thread, 原型：ngx_int_t (*init_thread)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit thread, 原型：void (*exit_thread)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit process, 原型：void (*exit_process)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit master, 原型：void (*exit_master)(ngx_cycle_t *cycle);*/
    NGX_MODULE_V1_PADDING
};


static u_char ngx_hello_world[] = "hello world";
/*命名规则：ngx_http_<模块名称>_handler*/
static ngx_int_t ngx_http_hello_world_handler(ngx_http_request_t *r)
{
    ngx_buf_t   *b;
    ngx_chain_t out;

    r->headers_out.content_type.len = sizeof("text/html") - 1;
    r->headers_out.content_type.data = (u_char*)"text/html";

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));

    out.buf = b;
    out.next = NULL;

    b->pos = ngx_hello_world;
    b->last = ngx_hello_world + sizeof(ngx_hello_world);
    b->memory = 1;
    b->last_buf = 1;

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = sizeof(ngx_hello_world);
    ngx_http_send_header(r);

    return ngx_http_output_filter(r, &out);
}

/*
 * 函数名命名规则：ngx_http_<模块名称>
 * cf：指向ngx_conf_t结构体的指针，包含从指令后面传过来的参数
 * cmd：指向当前ngx_command_t结构体的指针
 * conf：指向自定义模块配置结构体的指针
 * */
static char *ngx_http_hello_world(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_hello_world_handler;

    return NGX_CONF_OK;
}
