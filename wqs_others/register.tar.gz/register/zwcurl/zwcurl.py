#!/usr/bin/python

import pycurl

class ZwCurl:
	
	def __init__(self):
		self.url           = ''
		self.send_msg      = ''
		self.recv_msg      = ''
		self.upload_file   = ''
		self.download_file = ''
		self.http_method   = 0
		self.response_code = 0	
		self.curl          = pycurl.Curl()
		self.status        = 0
		
		self.GET           = 1
		self.POST          = 2
		self.GET_WITH_DOWNLOADFILE = 3
		self.POST_WITH_UPLOADFILE  = 4

	def ZwCurlWriteFunc(self, data):
		self.recv_msg = self.recv_msg + data
		
	def ZwCurlPerform(self):
		self.curl.setopt(self.curl.URL, self.url)
		self.curl.setopt(self.curl.WRITEFUNCTION, self.ZwCurlWriteFunc)
		self.curl.setopt(pycurl.HTTPHEADER, ['Content-Type: application/txt'])

		if self.http_method == self.POST:
			self.curl.setopt(self.curl.POSTFIELDS, self.send_msg)
		else:
			print 'Unsupport Method...'
		try:	
			self.curl.perform()
		except Exception, e:
			print e
			self.status = -1
			return

		self.response_code = self.curl.getinfo(pycurl.HTTP_CODE)

	def ZwCurlDestroy(self):
		self.curl.close()
		
		
