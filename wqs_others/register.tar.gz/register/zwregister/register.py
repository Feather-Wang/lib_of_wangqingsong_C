#!/usr/bin/python

import os
import sys
import json
import ConfigParser

if '../zwcurl/' not in sys.path:
	sys.path.append('../zwcurl/')

from zwcurl import ZwCurl

class ZwRegister:
	def __init__(self, url='', data=''):
		self.url    = url
		self.data   = data
		self.resp   = ''
		self.status = 0

	def ZwRegisterGetConfig(self, path):
		dic = {}
		cf  = ConfigParser.ConfigParser()		
		try:	
			cf.read(path)
			value = cf.get('device', 'code')
			dic['code'] = value
			value = cf.get('device', 'dist')
			dic['dist'] = value
			value = cf.get('device', 'atrb')
			dic['atrb'] = value
			value = cf.get('device', 'descrip')
			dic['descrip'] = value
			value = cf.get('device', 'probeid')
			dic['probeid'] = value
			value = cf.get('device', 'probever')
			dic['probever'] = value
			value = cf.get('device', 'proberev')
			dic['proberev'] = value
			value = cf.get('device', 'unikey')
			dic['unikey'] = value

			value = cf.get('register', 'url')
			self.url = value
		except Exception, e:
			print e
			raise IndexError

		self.data = json.dumps(dic)
		

	def ZwRegisterDo(self):
		zc = ZwCurl()
		zc.url      = self.url
		zc.send_msg = self.data
		zc.http_method = zc.POST

		zc.ZwCurlPerform()
		if zc.status == -1:
			self.status = -1
			zc.ZwCurlDestroy()
			return
		
		print 'Register HTTP Code: %d' % zc.response_code
		self.resp = zc.recv_msg
		zc.ZwCurlDestroy()
		
		

if __name__ == '__main__':
	reg = ZwRegister()
	try:
		reg.ZwRegisterGetConfig('commoninfo.ini')
		reg.ZwRegisterDo()
	except Exception, e:
		print e
		sys.exit(-1)
		
	if reg.status == -1:
		print 'Register failed...'
		sys.exit(-1)
	print 'Register Url:' + reg.url
	print 'Register Send:' + reg.data
	print 'Register Recv:' + reg.resp
