#include "./xml.h"

int main(int argc, const char *argv[])
{
    CARDINFO cardinfo;

    memset(&cardinfo, 0, sizeof(cardinfo));

    get_cardinfo(&cardinfo);

    return 0;
}

// delete this node.
int del_node(xmlNodePtr node)
{
    xmlNodePtr tempNode = NULL;

    tempNode = node->next;

    xmlUnlinkNode( node );
    xmlFreeNode( node );

    node = tempNode;

    return 0;
}

int get_cardinfo(pCARDINFO cardinfo)
{
    xmlDocPtr doc = NULL;
    xmlNodePtr root_node = NULL,
               node_deviceinfo = NULL,
               node_taskinfo = NULL,
               tmp_root_node = NULL;
    xmlAttrPtr attrPtr = NULL;

    doc = xmlReadFile(URL_PROPERTIES_XML, ENCODING, 256);
    if( NULL == doc )
    {
        fprintf(stderr, "fopen %s failure : %s\n", URL_PROPERTIES_XML, strerror(errno));
        return -1;
    }

    root_node = xmlDocGetRootElement(doc);
    if( NULL == root_node || xmlStrcmp(root_node->name, (const xmlChar*)"properties") )
    {
        fprintf(stderr, "Get root node failure : %s\n", strerror(errno));
        return -1;
    }

    tmp_root_node = root_node->xmlChildrenNode;
    while( NULL != tmp_root_node )
    {
        if( !xmlStrcmp(tmp_root_node->name, (const xmlChar*)"device") )
        {
            printf("device...\n");
            if( -1 == get_deviceinfo(tmp_root_node, cardinfo) )
            {        
                fprintf(stderr, "Get cardinfo failure : %s\n", strerror(errno));
                return -1;
            }
        }
        else if( !xmlStrcmp(tmp_root_node->name, (const xmlChar*)"task") )
        {
            printf("task...\n");
            if( -1 == get_taskinfo(tmp_root_node, cardinfo) )
            {
                fprintf(stderr, "Get real ts number failure : %s\n", strerror(errno));
                return -1;
            }
        }

        tmp_root_node = tmp_root_node->next;
    }
    printf("end...\n");

    return 0;
}

int get_deviceinfo(xmlNodePtr deviceinfo, pCARDINFO cardinfo)
{
    printf("device start...\n");
    xmlNodePtr root_node = NULL;
    xmlAttrPtr attrPtr = NULL; // attribute collection point.
    xmlNodePtr propNodePtr = NULL;

    if( NULL == deviceinfo )
    {
        fprintf(stderr, "rootNode is NULL...\n");
        return -1;
    }
    root_node = deviceinfo;

    root_node = root_node->xmlChildrenNode;

    while( NULL != root_node )
    {
        if( !xmlStrcmp(root_node->name, (const xmlChar*)"deviceinfo") )
        {
            propNodePtr = root_node;
            break;
        }
        root_node = root_node->next;
    }

    if( NULL == propNodePtr )
    {
        fprintf(stderr, "Get device info failure...\n");
        return -1;
    }

    attrPtr = propNodePtr->properties; // properties is this node's attribute collection point.
    while( NULL != attrPtr )
    {
        xmlChar *szAttr = xmlGetProp( propNodePtr, BAD_CAST (attrPtr->name) ); // get this name attribute's value to szAttr.
        printf("%s = %s\n", attrPtr->name, (const char*)szAttr);
        if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"devicetype") )
        {
            if( !xmlStrcmp(szAttr, (const xmlChar*)"DVBC") )
            {
                cardinfo->devicetype = 2;
            }
        }
        else if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"IP") )
        {
            strncmp(cardinfo->tsip, (const char*)szAttr, strlen((char*)szAttr));
        }
        else if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"recordlist") )
        {
            char *p = NULL;
            char *q = szAttr;
            char tmp_buf[24];
            int index = 0;
            while(1)
            {
                memset(tmp_buf, 0, 24);
                p = strstr(q,";");
                if( NULL == p )
                    break;
                if( !strncpy(tmp_buf, p, p-q) )
                {
                    return -1;
                }
                tmp_buf[p-q] = '\0';
                cardinfo->tsnum[index++] = atoi(tmp_buf);
                cardinfo->tsnum_cout = index;
                q = p+1;
            }
        }
        else if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"cmdport") )
        {
            cardinfo->cmdport = atoi((char*)szAttr);
        }
        else if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"tsport") )
        {
            cardinfo->tsport = atoi((char*)szAttr);
        }

        xmlFree(szAttr);
        attrPtr = attrPtr->next;
    }

    return 0;
}

int get_taskinfo(xmlNodePtr taskinfo, pCARDINFO cardinfo)
{
    xmlNodePtr root_node = NULL;
    xmlAttrPtr attrPtr = NULL; // attribute collection point.
    xmlNodePtr propNodePtr = NULL;
    int streamreal_log = 0;

    if( NULL == taskinfo )
    {
        fprintf(stderr, "rootNode is NULL...\n");
        return -1;
    }
    root_node = taskinfo;

    root_node = root_node->xmlChildrenNode;

    while( NULL != root_node )
    {
        if( !xmlStrcmp(root_node->name, (const xmlChar*)"taskinfo") )
        {
            propNodePtr = root_node;
            break;
        }
        root_node = root_node->next;
    }

    if( NULL == propNodePtr )
    {
        fprintf(stderr, "Get device info failure...\n");
        return -1;
    }

    attrPtr = propNodePtr->properties; // properties is this node's attribute collection point.
    while( NULL != attrPtr )
    {
        xmlChar *szAttr = xmlGetProp( propNodePtr, BAD_CAST (attrPtr->name) ); // get this name attribute's value to szAttr.
        printf("%s = %s\n", attrPtr->name, (const char*)szAttr);
        if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"tasktype") )
        {
            if( !xmlStrcmp(szAttr, (const xmlChar*)"StreamRealtimeQueryTask") )
            {
                streamreal_log = 1;
            }
        }
        else if( !xmlStrcmp(attrPtr->name, (const xmlChar*)"devicelist") )
        {
            if( streamreal_log == 1 )
            {
                //cardinfo->realts_num = atoi((char*)szAttr);
            }
        }
        xmlFree(szAttr);

        attrPtr = attrPtr->next;
    }

    return 0;
}
