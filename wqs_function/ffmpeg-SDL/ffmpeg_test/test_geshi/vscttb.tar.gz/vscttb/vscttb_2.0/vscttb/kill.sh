killall -9 a.out
