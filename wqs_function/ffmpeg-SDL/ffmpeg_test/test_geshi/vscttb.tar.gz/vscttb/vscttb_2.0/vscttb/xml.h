#ifndef __XML_H__

#define __XML_H__

#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

#define URL_PROPERTIES_XML ("./properties.xml")
#define ENCODING ("UTF-8")

typedef struct _CardInfo_
{
    char tsip[24];
    int tsport;
    int cmdport;
    int devicetype;
    int tsnum[4];
    int tsnum_cout;
    int realts_num;
}CARDINFO, *pCARDINFO;

int get_cardinfo(pCARDINFO cardinfo);
int del_node(xmlNodePtr node);
int get_deviceinfo(xmlNodePtr deviceinfo, pCARDINFO cardinfo);
int get_taskinfo(xmlNodePtr taskinfo, pCARDINFO cardinfo);

//#define DEBUG
#ifdef DEBUG
int debug_index = 0;
#endif

#endif
