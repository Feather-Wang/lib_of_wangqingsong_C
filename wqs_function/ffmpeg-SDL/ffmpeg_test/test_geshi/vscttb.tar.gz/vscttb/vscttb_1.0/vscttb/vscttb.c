#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#define SERVER_IP "172.16.10.101"
#define SERVER_PORT 9999
#define MAXSIZE 20
#define UDP_SERVER_IP "172.16.10.101"
#define UDP_SERVER_PORT 10134

int send_ts(int fd);

int main(int argc, const char *argv[])
{
    int server_sockfd = -1;
    int clinet_sockfd = -1;
    int server_len;
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    char recv_buf[1024];
    char send_buf[1024];
    int ret = 0;

    printf("start...\n");

    signal(SIGPIPE, SIG_IGN);

    if((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("create socket failed:");
        close(server_sockfd);
        exit(-1);
    }
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_address.sin_port = htons(SERVER_PORT);
    server_len = sizeof(server_address);
    if(bind(server_sockfd, (struct sockaddr *)&server_address, server_len)!=0)
    {
        perror("bind:");
        close(server_sockfd);
        exit(-1);
    }
    if(listen(server_sockfd, 5)!=0)
    {
        perror("listen:");
        close(server_sockfd);
        exit(-1);
    }

    while(1)
    {
        clinet_sockfd = accept(server_sockfd,(struct sockaddr*)&client_address,&server_len);
        printf("new connection %d!\n", clinet_sockfd);
        if( clinet_sockfd <= 0 )
        {
            printf("accept error\n");
            continue;
        }

        while(1)
        {
            memset(recv_buf, 0, sizeof(recv_buf));

            ret = recv( clinet_sockfd, recv_buf, sizeof(recv_buf), 0);
            if( ret <= 0 )
            {
                continue;
            }

            printf("recv:\n%s\n", recv_buf);
            sprintf(send_buf, "HTTP/1.1 200 OK\r\n \
                    Content-Type: video/mpeg\r\n \
                    Cache-Control: no-cache\r\nContent-Length: 0-\r\n\r\n");
            ret = 0;
            ret = send( clinet_sockfd, send_buf, strlen(send_buf), 0);
            if( ret <= 0 )
            {
                printf("send error...\n");
            }
            else
            {
                send_ts(clinet_sockfd);
                break;
            }
        }

        close(clinet_sockfd);
    }		
}

int send_ts(int fd)
{
    printf("send_ts start...\n");

    char ts_buf[1880];
    size_t ts_len = 0;
    int ret = 0;
    int server_fd = -1;
    struct sockaddr_in server_addr,
                       client_addr;
    socklen_t clientaddr_len = 0;

    if ((server_fd = socket(PF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("fail to socket");
        exit(-1);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = PF_INET;
    server_addr.sin_port = htons(UDP_SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(UDP_SERVER_IP);
    //int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("fail to bind");
        exit(-1);
    }

    clientaddr_len = sizeof(client_addr);
    while ( 1 )
    {
        memset(&client_addr, 0, sizeof(client_addr));
        memset(ts_buf, 0, sizeof(ts_buf));
        ts_len = recvfrom(server_fd, ts_buf, 1880, 0, (struct sockaddr *)&client_addr, &clientaddr_len);

        if( ts_len > 0 )
        {
            printf("read:%d\n", ts_len);
            ret = send(fd, ts_buf, ts_len, 0);
            printf("ret = %d\n",ret);
            if( ret <= 0 )
            {
                continue;
            }
            else
            {
                ret = 0;
            }

            ts_len = 0;
        }
    }

    printf("ts send end...\n");
    return 0;
}
