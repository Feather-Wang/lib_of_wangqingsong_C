#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_log.h>

/*用于存储命令参数的结构体*/
typedef struct
{
    ngx_str_t output_words;
} ngx_http_hello_nginx_loc_conf_t;

/*函数声明*/
static char * ngx_http_hello_nginx( ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static void * ngx_http_hello_nginx_create_loc_conf( ngx_conf_t *cf );
static char * ngx_http_hello_nginx_merge_loc_conf( ngx_conf_t *cf, void *parent, void *child );

/*定义模块支持的指令数组*/
/*命名规则：ngx_http_<模块名称>_commands*/
static ngx_command_t ngx_http_hello_nginx_commands[] = 
{
    {
        ngx_string("hello_nginx"),              /*指定模块在配置文件中的指令名称，不能有空格，大小写敏感，数据类型为ngx_str_t*/
        NGX_HTTP_LOC_CONF | NGX_CONF_TAKE1,     /*指令的作用域以及参数的个数，多个设定用'|'连接*/
        ngx_http_hello_nginx,                   /*指令的执行函数*/
        NGX_HTTP_LOC_CONF_OFFSET,               /*用于告诉nginx是把要保持的值放在全局配置部分，server主机配置部分，还是location配置部分，具体的值有nginx定义的宏*/
        offsetof(ngx_http_hello_nginx_loc_conf_t, output_words),    /*在location块中的偏移*/
        NULL
    },
    ngx_null_command
};

/*命名规则：ngx_http_<模块名称>_module_ctx*/
/*定义模块上下文结构体*/
static ngx_http_module_t ngx_http_hello_nginx_module_ctx = 
{
    NULL,                                   /*读入配置前调用, 原型：ngx_int_t (*preconfiguration)(ngx_conf_t *cf)*/
    NULL,                                   /*读入配置后调用, 原型：ngx_int_t (*postconfiguration)(ngx_conf_t *cf)*/

    NULL,                                   /*创建全局部分配置时调用, 原型：void *(*create_main_conf)(ngx_conf_t *cf)*/
    NULL,                                   /*初始化全局部分的配置时调用, 原型：char *(*init_main_conf)(ngx_conf_t *cf, void *conf)*/

    NULL,                                   /*创建虚拟主机部分的配置时调用, 原型：void *(*create_srv_conf)(ngx_conf_t *cf)*/
    NULL,                                   /*与全局部分配置合并时调用, 原型：char *(*merge_srv_conf)(ngx_conf_t *cf, void *prev, void *conf)*/

    ngx_http_hello_nginx_create_loc_conf,   /*创建location部分的配置时调用, 原型：void *(*create_loc_conf)(ngx_conf_t *cf)*/
    ngx_http_hello_nginx_merge_loc_conf     /*与虚拟主机部分配置合并时调用, 原型：char *(*merge_loc_conf)(ngx_conf_t *cf, void *prev, void *conf)*/
};

/*定义模块的主结构体*/
/*命名规则：ngx_http_<模块名称>_module*/
ngx_module_t ngx_http_hello_nginx_module =
{
    NGX_MODULE_V1,                          /*模块版本*/
    &ngx_http_hello_nginx_module_ctx,       /*指向特定类型模块的公共接口*/
    ngx_http_hello_nginx_commands,          /*用于处理配置文件nginx.conf中的配置项*/
    NGX_HTTP_MODULE,                        /*当前模块类型*/

    NULL,                                   /*init master, 原型：ngx_int_t (*init_master)(ngx_log_t *log);*/
    NULL,                                   /*init module, 原型：ngx_int_t (*init_module)(ngx_cycle_t*cycle);*/
    NULL,                                   /*init process, 原型：ngx_int_t (*init_process)(ngx_cycle_t *cycle);*/
    NULL,                                   /*init thread, 原型：ngx_int_t (*init_thread)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit thread, 原型：void (*exit_thread)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit process, 原型：void (*exit_process)(ngx_cycle_t *cycle);*/
    NULL,                                   /*exit master, 原型：void (*exit_master)(ngx_cycle_t *cycle);*/
    NGX_MODULE_V1_PADDING
};

u_char ngx_print[] = "Hello, my new Nginx!";    /*要输出的内容*/
/*命名规则：ngx_http_<模块名称>_handler*/
static ngx_int_t ngx_http_hello_nginx_handler( ngx_http_request_t *r )
{
    ngx_int_t       rc;
    ngx_buf_t       *b;
    ngx_chain_t     out[2];
    ngx_http_hello_nginx_loc_conf_t *hlcf;

    /*可以打印error日志*/
    ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "handler----------------------------");

    r->headers_out.content_type.len = sizeof("text/html") - 1;
    r->headers_out.content_type.data = (u_char *)"text/html";

    b = ngx_pcalloc( r->pool, sizeof(ngx_buf_t) );
    out[0].buf = b;
    out[0].next = &out[1];
    b->pos = (u_char *)ngx_print;
    b->last = b->pos + sizeof(ngx_print) - 1;
    b->memory = 1;
    
    hlcf = ngx_http_get_module_loc_conf( r, ngx_http_hello_nginx_module );

    b = ngx_pcalloc( r->pool, sizeof(ngx_buf_t) );
    out[1].buf = b;
    out[1].next = NULL;
    b->pos = hlcf->output_words.data;
    b->last = b->pos + (hlcf->output_words.len);
    b->memory = 1;
    b->last_buf = 1;

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = hlcf->output_words.len + sizeof(ngx_print) - 1;
    
    rc = ngx_http_send_header(r);
    if( rc == NGX_ERROR || rc > NGX_OK || r->header_only )
    {
        return rc;
    }

    return ngx_http_output_filter( r, &out[0] );
}

static void* ngx_http_hello_nginx_create_loc_conf( ngx_conf_t* cf )
{
    ngx_http_hello_nginx_loc_conf_t* conf;
    conf = ngx_pcalloc( cf->pool, sizeof(ngx_http_hello_nginx_loc_conf_t) );
    if( conf == NULL )
        return NGX_CONF_ERROR;

    conf->output_words.len = 0;
    conf->output_words.data = NULL;

    return conf;
}

static char* ngx_http_hello_nginx_merge_loc_conf( ngx_conf_t* cf, void* parent, void* child )
{
    ngx_http_hello_nginx_loc_conf_t* prev = parent;
    ngx_http_hello_nginx_loc_conf_t* conf = child;

    ngx_conf_merge_str_value( conf->output_words, prev->output_words, "Nginx");

    return NGX_CONF_OK;
}

/*
 * 函数名命名规则：ngx_http_<模块名称>
 * cf：指向ngx_conf_t结构体的指针，包含从指令后面传过来的参数
 * cmd：指向当前ngx_command_t结构体的指针
 * conf：指向自定义模块配置结构体的指针
 * */
static char* ngx_http_hello_nginx( ngx_conf_t* cf, ngx_command_t* cmd, void* conf )
{
    ngx_http_core_loc_conf_t* clcf;
    /*传入模块主结构体*/
    clcf = ngx_http_conf_get_module_loc_conf( cf, ngx_http_core_module );
    clcf->handler = ngx_http_hello_nginx_handler;

    ngx_conf_set_str_slot( cf, cmd, conf );

    return NGX_CONF_OK;
}
