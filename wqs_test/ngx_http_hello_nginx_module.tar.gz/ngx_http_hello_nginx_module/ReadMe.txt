编译时，将该目录放入到/nginx/src/目录下
./configure --add-module=该目录的全路径
make
make install
